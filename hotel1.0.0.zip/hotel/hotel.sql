/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 10.4.28-MariaDB : Database - hotel
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`hotel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `hotel`;

/*Table structure for table `log_in` */

DROP TABLE IF EXISTS `log_in`;

CREATE TABLE `log_in` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `log_in` */

insert  into `log_in`(`username`,`password`) values 
('admin','1234');

/*Table structure for table `tabel_checkin` */

DROP TABLE IF EXISTS `tabel_checkin`;

CREATE TABLE `tabel_checkin` (
  `nama` varchar(50) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `nomor_telepon` varchar(12) NOT NULL,
  `kewarganegaraan` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `nomor_kamar` varchar(10) NOT NULL,
  `tipe_kamar` varchar(10) NOT NULL,
  `tipe_ranjang` varchar(10) NOT NULL,
  `tanggal_checkin` date NOT NULL,
  `tanggal_checkout` date NOT NULL,
  `harga` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tabel_checkin` */

insert  into `tabel_checkin`(`nama`,`nik`,`jenis_kelamin`,`email`,`nomor_telepon`,`kewarganegaraan`,`alamat`,`nomor_kamar`,`tipe_kamar`,`tipe_ranjang`,`tanggal_checkin`,`tanggal_checkout`,`harga`) values 
('Shabrina Naila','1111111111111111 ','Perempuan ','thefifthoftheseventh@gmail.com','08979662763 ','India ','Jl. Bojong Malaka ','307 ','Deluxe ','Double ','2023-07-21','2023-07-23',1700000),
('Sigit Sulistyo','32789645222','Laki-laki','sigits@gmail.com','0897563241','Indonesia','Surabaya','305','Deluxe','Double','2023-07-07','2023-07-08',850000),
('Rahmi Diah Rahmah','3278964532159','Perempuan','diahmimah@gmail.com','0859632578','Indonesia','Bali','101','Standar','Single','2023-07-14','2023-07-15',200000),
('Siti Muslichan','327956324216987','Perempuan','sitichan@gmail.com','0895246398','Indonesia','Bandung','102','Standar','Single','2023-07-14','2023-07-15',200000),
('Maulana Glend','3279864531368759','Laki-laki','glendmaul@gmail.com','0895675682','Indonesia','Jakarta','106','Standar','Double','2023-07-12','2023-07-14',300000),
('Titus Gemala','327986542397','Laki-laki','tigemala@yahoo.com','08876564212','Indonesia','Lampung','301','Deluxe','Single','2023-07-13','2023-07-14',750000),
('Mamat Sudrajat','3265745678978900 ','Laki-laki ','mamat@gmail.com ','089507599251','Indonesia ','Sukabumi ','302 ','Deluxe ','Single ','2023-07-23','2023-07-24',1500000),
('Dinda Nur','3256745678009876 ','Perempuan ','dinda@gmail.com ','089507599652','Indonesia ','Baleendah ','309 ','Deluxe ','Twin ','2023-07-24','2023-07-25',950000),
('Sumbul','3214270705020008 ','Laki-laki ','sumbul@email.com ','082143434343','Indonesia ','Jl. Kaktus 9 ','104 ','Standard ','Single ','2023-07-23','2023-07-25',400000);

/*Table structure for table `tabel_checkout` */

DROP TABLE IF EXISTS `tabel_checkout`;

CREATE TABLE `tabel_checkout` (
  `nama` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nomor_kamar` int(11) NOT NULL,
  `tipe_kamar` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tipe_ranjang` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tanggal_checkin` date NOT NULL,
  `tanggal_checkout` date NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_danish_ci;

/*Data for the table `tabel_checkout` */

insert  into `tabel_checkout`(`nama`,`nomor_kamar`,`tipe_kamar`,`tipe_ranjang`,`tanggal_checkin`,`tanggal_checkout`,`total_harga`) values 
('Maulana Glend',106,'Standar','Double','2023-07-12','2023-07-14',300000),
('Titus Gemala',301,'Deluxe','Single','2023-07-13','2023-07-14',750000),
('Sigit Sulistyo',305,'Deluxe','Double','2023-07-07','2023-07-08',850000),
('Asep Satriawan',101,'Standard ','Single ','2023-07-20','2023-07-21',200000),
('Sumbul',104,'Standard ','Single ','2023-07-25','2023-07-23',400000);

/*Table structure for table `tabel_kamar` */

DROP TABLE IF EXISTS `tabel_kamar`;

CREATE TABLE `tabel_kamar` (
  `nomor_kamar` varchar(3) NOT NULL,
  `tipe_kamar` varchar(10) DEFAULT NULL,
  `tipe_ranjang` varchar(10) DEFAULT NULL,
  `harga` int(7) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'kosong',
  PRIMARY KEY (`nomor_kamar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tabel_kamar` */

insert  into `tabel_kamar`(`nomor_kamar`,`tipe_kamar`,`tipe_ranjang`,`harga`,`status`) values 
('101','Standard','Single',200000,'Kosong'),
('102','Standard','Single',200000,'Kosong'),
('103','Standard','Single',200000,'Kosong'),
('104','Standard','Single',200000,'Kosong'),
('105','Standard','Double',300000,'Kosong'),
('106','Standard','Double',300000,'Kosong'),
('107','Standard','Double',300000,'Kosong'),
('108','Standard','Double',300000,'Kosong'),
('109','Standard','Twin',400000,'Kosong'),
('110','Standard','Twin',400000,'Kosong'),
('111','Standard','Twin',400000,'Kosong'),
('112','Standard','Twin',400000,'Kosong'),
('201','Family','Double',550000,'Terisi'),
('202','Family','Double',550000,'Kosong'),
('203','Family','Double',550000,'Kosong'),
('204','Family','Double',550000,'Kosong'),
('205','Family','Double',550000,'Kosong'),
('206','Family','Double',550000,'Terisi'),
('207','Family','Mix',650000,'Kosong'),
('208','Family','Mix',650000,'Kosong'),
('209','Family','Mix',650000,'Kosong'),
('210','Family','Mix',650000,'Kosong'),
('211','Family','Mix',650000,'Kosong'),
('212','Family','Mix',650000,'Kosong'),
('301','Deluxe','Single',750000,'Terisi'),
('302','Deluxe','Single',750000,'Terisi'),
('303','Deluxe','Single',750000,'Kosong'),
('304','Deluxe','Single',750000,'Kosong'),
('305','Deluxe','Double',850000,'Terisi'),
('306','Deluxe','Double',850000,'Kosong'),
('307','Deluxe','Double',850000,'Terisi'),
('308','Mistis','Double',1200000,'Kosong'),
('309','Deluxe','Twin',950000,'Kosong'),
('310','Deluxe','Twin',950000,'Kosong'),
('311','Deluxe','Twin',950000,'Kosong'),
('312','Deluxe','Twin',950000,'Kosong');

/*Table structure for table `tabel_penginap` */

DROP TABLE IF EXISTS `tabel_penginap`;

CREATE TABLE `tabel_penginap` (
  `nama` varchar(50) NOT NULL,
  `nomor_kamar` varchar(10) NOT NULL,
  `tanggal_checkin` date DEFAULT NULL,
  PRIMARY KEY (`nomor_kamar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tabel_penginap` */

/*Table structure for table `tabel_transaksi` */

DROP TABLE IF EXISTS `tabel_transaksi`;

CREATE TABLE `tabel_transaksi` (
  `nama` varchar(20) NOT NULL,
  `tipe_kamar` varchar(20) NOT NULL,
  `tipe_ranjang` varchar(20) NOT NULL,
  `nomor_kamar` int(11) NOT NULL,
  `tanggal_checkin` date NOT NULL,
  `tanggal_checkout` date NOT NULL,
  `total_hari` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `pembayaran` varchar(20) NOT NULL,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tabel_transaksi` */

insert  into `tabel_transaksi`(`nama`,`tipe_kamar`,`tipe_ranjang`,`nomor_kamar`,`tanggal_checkin`,`tanggal_checkout`,`total_hari`,`total_harga`,`pembayaran`) values 
('Fida Rahima','Deluxe ','Double ',307,'2023-07-15','2023-07-16',1,850000,'debit '),
('Maulana Glend','Standard','Single',101,'2023-07-12','2023-07-14',2,600000,'cash'),
('Rudi Tabuti','Standard ','Single ',102,'2023-06-11','2023-06-13',2,400000,'debit '),
('Sigit Sulistyo','Standard','Double',107,'2023-07-07','2023-07-08',1,850000,'debit'),
('Sumbul','Standard ','Single ',104,'2023-07-23','2023-07-25',2,400000,'debit '),
('Titus Gemala','Deluxe','Single',302,'2023-07-13','2023-07-14',1,750000,'debit');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
