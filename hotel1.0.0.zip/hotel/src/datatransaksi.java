
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author HP
 */
public class datatransaksi extends javax.swing.JFrame {
koneksi dbsetting;
String driver,database,user,pass;
DecimalFormat kurs;
DecimalFormatSymbols format;

    /**
     * Creates new form datatransaksi
     */
    public datatransaksi() {
        initComponents();
        
        dbsetting = new koneksi();
        driver = dbsetting.SettingPanel("DBDriver");
        database = dbsetting.SettingPanel("DBDatabase");
        user = dbsetting.SettingPanel("DBUsername");
        pass = dbsetting.SettingPanel("DBPassword");
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        txt_transaksi_date.setText(formatter.format(cal.getTime()));
        txt_transaksi_date2.setText(formatter.format(cal.getTime()));
        
        kurs = (DecimalFormat)DecimalFormat.getInstance();
        format = new DecimalFormatSymbols();
        format.setMonetaryDecimalSeparator(',');
        format.setGroupingSeparator('.');
        kurs.setDecimalFormatSymbols(format);
        
        /* menyembunyikan field */
        txt_transaksi_temp.setVisible(false);
        txt_transaksi_temp.revalidate();
        txt_transaksi_temp.repaint();
        
        dayCounter();
    }
    
        public void updateRoomComboBox() {
        combo_transaksi_nomor.removeAllItems();
        String tipe = combo_transaksi_tipe.getSelectedItem().toString();
        String ranjang = combo_transaksi_bed.getSelectedItem().toString();
         try {
             // menghubungkan koneksi ke database
            Connection kon = DriverManager.getConnection(database,user,pass);
            // query untuk mengambil data tipe kamar dan tipe ranjaang dari database
            // dengan kondisi status kamar harus 'kosong'
            String query = "SELECT nomor_kamar FROM tabel_kamar WHERE tipe_kamar = ? AND tipe_ranjang = ? ";
            PreparedStatement statement = kon.prepareStatement(query);
            statement.setString(1, tipe);
            statement.setString(2, ranjang);
            ResultSet resultSet = statement.executeQuery();

            // memasukkan data ke combo box nomor kamar
            while (resultSet.next()) {
                String nomor = resultSet.getString("nomor_kamar");
                combo_transaksi_nomor.addItem(nomor);
            }

            resultSet.close();
            statement.close();
            kon.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }  
    }
    
     public void updateBedComboBox() {
        combo_transaksi_bed.removeAllItems();
        String type = combo_transaksi_tipe.getSelectedItem().toString();
        if (type.equals("Standard")) {
            combo_transaksi_bed.addItem("Single");
            combo_transaksi_bed.addItem("Double");
            combo_transaksi_bed.addItem("Twin");
        } else if (type.equals("Deluxe")) {
            combo_transaksi_bed.addItem("Single");
            combo_transaksi_bed.addItem("Double");
            combo_transaksi_bed.addItem("Twin");
        } else if (type.equals("Family")) {
            combo_transaksi_bed.addItem("Double");
            combo_transaksi_bed.addItem("Mix");
        }
        updateRoomComboBox();
    }
    
    double hargaHari;
    long days;
    double valuedb;
    
   public void updatePrice() {
        // mengambil data dari combo box tipe kamar dan tipe ranjang
        String tipe = combo_transaksi_tipe.getSelectedItem().toString();
        String ranjang = combo_transaksi_bed.getSelectedItem().toString();

        // Penghitung jumlah hari
        SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");
        String inputString1 = txt_transaksi_date.getText();
        String inputString2 = txt_transaksi_date2.getText();

        try {
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            // menghubungkan koneksi ke database
            Connection kon = DriverManager.getConnection(database,user,pass);
            // query untuk mengambil data dari setiap combo box
            String SQL = "SELECT harga FROM tabel_kamar WHERE tipe_kamar = ? AND tipe_ranjang = ?";
            PreparedStatement statement = kon.prepareStatement(SQL);
            statement.setString(1, tipe);
            statement.setString(2, ranjang);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Date date1 = dtf.parse(inputString1);
                Date date2 = dtf.parse(inputString2);
                // konversi tanggal untuk dihitung selisihnya
                long timeDiff = Math.abs(date2.getTime()- date1.getTime());
                long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
                txt_transaksi_hari.setText(String.valueOf(daysDiff));
                int harga = resultSet.getInt("harga");
                double value = harga*daysDiff;
                txt_transaksi_temp.setText(String.valueOf(value));
                txt_transaksi_harga.setText(String.valueOf(kurs.format(value)));
            }

            resultSet.close();
            statement.close();
            kon.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }
   
   private void dayCounter(){
       // Penghitung jumlah hari
        SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");
        String inputString1 = txt_transaksi_date.getText();
        String inputString2 = txt_transaksi_date2.getText();
        
        try {
            Date date1 = dtf.parse(inputString1);
            Date date2 = dtf.parse(inputString2);
            // konversi tanggal untuk dihitung selisihnya
            long timeDiff = Math.abs(date2.getTime()- date1.getTime());
            long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
            txt_transaksi_hari.setText(String.valueOf(daysDiff));
            
            
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }

   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nama = new javax.swing.JLabel();
        txt_transaksi_nama = new javax.swing.JTextField();
        cekin = new javax.swing.JLabel();
        txt_transaksi_date = new javax.swing.JTextField();
        txt_transaksi_date2 = new javax.swing.JTextField();
        cekot = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        txt_transaksi_hari = new javax.swing.JTextField();
        harga = new javax.swing.JLabel();
        txt_transaksi_harga = new javax.swing.JTextField();
        nomor = new javax.swing.JLabel();
        btn_submit = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        combo_transaksi_nomor = new javax.swing.JComboBox<>();
        combo_transaksi_pembayaran = new javax.swing.JComboBox<>();
        bayar = new javax.swing.JLabel();
        combo_transaksi_bed = new javax.swing.JComboBox<>();
        ranjang = new javax.swing.JLabel();
        combo_transaksi_tipe = new javax.swing.JComboBox<>();
        kamar = new javax.swing.JLabel();
        txt_transaksi_temp = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(18, 25, 44));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(242, 242, 242));
        jLabel1.setText("TRANSAKSI BARU");

        nama.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nama.setForeground(new java.awt.Color(242, 242, 242));
        nama.setText("Nama");

        txt_transaksi_nama.setMinimumSize(new java.awt.Dimension(64, 25));

        cekin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cekin.setForeground(new java.awt.Color(242, 242, 242));
        cekin.setText("Tanggal Check-In");

        txt_transaksi_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_transaksi_dateActionPerformed(evt);
            }
        });
        txt_transaksi_date.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_transaksi_dateKeyReleased(evt);
            }
        });

        txt_transaksi_date2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_transaksi_date2ActionPerformed(evt);
            }
        });
        txt_transaksi_date2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_transaksi_date2KeyReleased(evt);
            }
        });

        cekot.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cekot.setForeground(new java.awt.Color(242, 242, 242));
        cekot.setText("Tanggal Check-Out");

        total.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        total.setForeground(new java.awt.Color(242, 242, 242));
        total.setText("Total Hari");

        harga.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        harga.setForeground(new java.awt.Color(242, 242, 242));
        harga.setText("Harga");

        nomor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nomor.setForeground(new java.awt.Color(242, 242, 242));
        nomor.setText("No. Kamar");

        btn_submit.setBackground(new java.awt.Color(249, 56, 33));
        btn_submit.setForeground(new java.awt.Color(242, 242, 242));
        btn_submit.setText("SUBMIT");
        btn_submit.setBorderPainted(false);
        btn_submit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_submitMouseClicked(evt);
            }
        });
        btn_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_submitActionPerformed(evt);
            }
        });

        jTextField7.setEditable(false);
        jTextField7.setBackground(new java.awt.Color(249, 56, 33));
        jTextField7.setBorder(null);

        combo_transaksi_pembayaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "cash", "debit" }));

        bayar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bayar.setForeground(new java.awt.Color(242, 242, 242));
        bayar.setText("Pembayaran");

        combo_transaksi_bed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_transaksi_bedActionPerformed(evt);
            }
        });

        ranjang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ranjang.setForeground(new java.awt.Color(242, 242, 242));
        ranjang.setText("Tipe Ranjang");

        combo_transaksi_tipe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Standard", "Family", "Deluxe" }));
        combo_transaksi_tipe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_transaksi_tipeActionPerformed(evt);
            }
        });

        kamar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        kamar.setForeground(new java.awt.Color(242, 242, 242));
        kamar.setText("Tipe Kamar");

        txt_transaksi_temp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_transaksi_tempActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addComponent(cekin)
                    .addComponent(txt_transaksi_date)
                    .addComponent(txt_transaksi_date2)
                    .addComponent(cekot)
                    .addComponent(nama)
                    .addComponent(txt_transaksi_nama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_transaksi_hari, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                    .addComponent(harga)
                    .addComponent(total)
                    .addComponent(txt_transaksi_harga))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_submit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(combo_transaksi_bed, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(combo_transaksi_tipe, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(nomor)
                                        .addComponent(bayar)
                                        .addComponent(combo_transaksi_nomor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(combo_transaksi_pembayaran, 0, 298, Short.MAX_VALUE))
                                    .addComponent(ranjang)
                                    .addComponent(kamar))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
                        .addComponent(txt_transaksi_temp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_transaksi_temp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(nama)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_transaksi_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(kamar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(combo_transaksi_tipe, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(cekin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_transaksi_date, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(ranjang)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(combo_transaksi_bed, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cekot)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_transaksi_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bayar)
                            .addComponent(total))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(combo_transaksi_pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_transaksi_hari, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(nomor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(combo_transaksi_nomor, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(8, 8, 8)
                .addComponent(harga)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_transaksi_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_submit, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_submitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_submitActionPerformed

    private void btn_submitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_submitMouseClicked
        // TODO add your handling code here:
        if(txt_transaksi_nama.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong, silahkan dilengkapi!");
            txt_transaksi_nama.requestFocus();
        }
        // jika sudah diisi
        else{
            try{
                // menghubungkan koneksi ke database
                Class.forName(driver);
                Connection kon = DriverManager.getConnection(database,user,pass);
                Statement stt=kon.createStatement();
                // query yang akan digunakan untuk memasukkan data yang telah diisi
                String SQL = "INSERT INTO tabel_transaksi(nama,"
                        + "tipe_kamar, "
                        + "tipe_ranjang, "
                        + "nomor_kamar, "
                        + "tanggal_checkin, "
                        + "tanggal_checkout, "
                        + "total_hari, "
                        + "total_harga, "
                        + "pembayaran)"
                        + "VALUES"
                        // pengambilan data dari setiap field dan combo box
                        + "('"+txt_transaksi_nama.getText()+"',"
                         + " '"+combo_transaksi_tipe.getSelectedItem().toString()+" ',"
                        + " '"+combo_transaksi_bed.getSelectedItem().toString()+" ',"
                        + " '"+combo_transaksi_nomor.getSelectedItem().toString()+" ',"
                        + " '"+txt_transaksi_date.getText()+" ',"
                        + " '"+txt_transaksi_date2.getText()+" ',"
                        + " '"+txt_transaksi_hari.getText()+" ',"
                        + " '"+txt_transaksi_temp.getText()+" ',"
                        + " '"+combo_transaksi_pembayaran.getSelectedItem().toString()+" ');";
                
                stt.executeUpdate(SQL);
                stt.close();
                kon.close();
                
                JOptionPane.showMessageDialog(null, "Data berhasil tersimpan!");
                setVisible(false);
                }
            catch(Exception ex){
                JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_submitMouseClicked

    private void combo_transaksi_bedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_transaksi_bedActionPerformed
        // TODO add your handling code here:
        updatePrice();
        updateRoomComboBox();
    }//GEN-LAST:event_combo_transaksi_bedActionPerformed

    private void combo_transaksi_tipeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_transaksi_tipeActionPerformed
        // TODO add your handling code here:
        updateBedComboBox();
        updateRoomComboBox();
    }//GEN-LAST:event_combo_transaksi_tipeActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
         try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Medium.ttf"));
            fn = fn.deriveFont(Font.PLAIN,18);
            jLabel1.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
         
         try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Bold.ttf"));
            fn = fn.deriveFont(Font.PLAIN,12);
            btn_submit.setFont(fn);
            cekin.setFont(fn);
            cekot.setFont(fn);
            nama.setFont(fn);
            total.setFont(fn);
            bayar.setFont(fn);
            kamar.setFont(fn);
            ranjang.setFont(fn);
            nomor.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void txt_transaksi_tempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_transaksi_tempActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_transaksi_tempActionPerformed

    private void txt_transaksi_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_transaksi_dateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_transaksi_dateActionPerformed

    private void txt_transaksi_date2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_transaksi_date2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_transaksi_date2ActionPerformed

    private void txt_transaksi_dateKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_transaksi_dateKeyReleased
        // TODO add your handling code here:
        dayCounter();
        updatePrice();
    }//GEN-LAST:event_txt_transaksi_dateKeyReleased

    private void txt_transaksi_date2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_transaksi_date2KeyReleased
        // TODO add your handling code here:
        dayCounter();
        updatePrice();
    }//GEN-LAST:event_txt_transaksi_date2KeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(datatransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(datatransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(datatransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(datatransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new datatransaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bayar;
    private javax.swing.JButton btn_submit;
    private javax.swing.JLabel cekin;
    private javax.swing.JLabel cekot;
    private javax.swing.JComboBox<String> combo_transaksi_bed;
    private javax.swing.JComboBox<String> combo_transaksi_nomor;
    private javax.swing.JComboBox<String> combo_transaksi_pembayaran;
    private javax.swing.JComboBox<String> combo_transaksi_tipe;
    private javax.swing.JLabel harga;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JLabel kamar;
    private javax.swing.JLabel nama;
    private javax.swing.JLabel nomor;
    private javax.swing.JLabel ranjang;
    private javax.swing.JLabel total;
    private javax.swing.JTextField txt_transaksi_date;
    private javax.swing.JTextField txt_transaksi_date2;
    private javax.swing.JTextField txt_transaksi_harga;
    private javax.swing.JTextField txt_transaksi_hari;
    private javax.swing.JTextField txt_transaksi_nama;
    private javax.swing.JTextField txt_transaksi_temp;
    // End of variables declaration//GEN-END:variables
}
