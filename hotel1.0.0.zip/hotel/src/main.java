public class main {
    public static void main(String[] args) {
        // TODO code application logic here
//        frm_navbar list = new frm_navbar();
//        list.setVisible(true);
          login Login = new login();
          Login.setVisible(true);
    }
}
