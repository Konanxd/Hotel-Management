
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.*;
//Fungsi import yang digunakan untuk SQL
import java.sql.*;
//Fungsi import yang digunakan untuk Tanggal
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
//fungsi import yang digunakan untuk format Rupiah
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */

/**
 *
 * @author Deedz!
 */
public class checkin extends javax.swing.JInternalFrame {
// deklarasi variabel yang diperlukan
koneksi dbsetting;
String driver,database,user,pass;
DecimalFormat kurs;
DecimalFormatSymbols format;

    /**
     * Creates new form checkin
     */
    public checkin() {
        initComponents();
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
        
        // koneksi ke database
        dbsetting = new koneksi();
        driver = dbsetting.SettingPanel("DBDriver");
        database = dbsetting.SettingPanel("DBDatabase");
        user = dbsetting.SettingPanel("DBUsername");
        pass = dbsetting.SettingPanel("DBPassword");
        
        /* konversi penanggalan ke format mysql serta pengambilan tanggal secara otomatis */
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        txt_checkin_date.setText(formatter.format(cal.getTime()));
        txt_checkin_date2.setText(formatter.format(cal.getTime()));
        
        /* format rupiah */
        kurs = (DecimalFormat)DecimalFormat.getInstance();
        format = new DecimalFormatSymbols();
        format.setMonetaryDecimalSeparator(',');
        format.setGroupingSeparator('.');
        kurs.setDecimalFormatSymbols(format);
        
        /* menyembunyikan field */
        txt_checkin_temp.setVisible(false);
        txt_checkin_temp.revalidate();
        txt_checkin_temp.repaint();
        
    }
    
    
    
    public void membersihkan_teks(){
        txt_checkin_nama.setText("");
        txt_checkin_nik.setText("");
        txt_checkin_email.setText("");
        txt_checkin_kewarganegaraan.setText("");
        txt_checkin_telepon.setText("");
        txt_checkin_date2.setText("");
    }
    
    /* method pengisi item combo box nomor ruangan */
    public void updateRoomComboBox() {
        combo_checkin_nomor.removeAllItems();
        String tipe = combo_checkin_tipe.getSelectedItem().toString();
        String ranjang = combo_checkin_bed.getSelectedItem().toString();
         try {
             // menghubungkan koneksi ke database
            Connection kon = DriverManager.getConnection(database,user,pass);
            // query untuk mengambil data tipe kamar dan tipe ranjaang dari database
            // dengan kondisi status kamar harus 'kosong'
            String query = "SELECT nomor_kamar FROM tabel_kamar WHERE tipe_kamar = ? AND tipe_ranjang = ? AND status = 'Kosong'";
            PreparedStatement statement = kon.prepareStatement(query);
            statement.setString(1, tipe);
            statement.setString(2, ranjang);
            ResultSet resultSet = statement.executeQuery();

            // memasukkan data ke combo box nomor kamar
            while (resultSet.next()) {
                String nomor = resultSet.getString("nomor_kamar");
                combo_checkin_nomor.addItem(nomor);
            }

            resultSet.close();
            statement.close();
            kon.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
        
        
    }
    
    // method pengisi item combo box tipe ranjang
    public void updateBedComboBox() {
        combo_checkin_bed.removeAllItems();
        String type = combo_checkin_tipe.getSelectedItem().toString();
        if (type.equals("Standard")) {
            combo_checkin_bed.addItem("Single");
            combo_checkin_bed.addItem("Double");
            combo_checkin_bed.addItem("Twin");
        } else if (type.equals("Deluxe")) {
            combo_checkin_bed.addItem("Single");
            combo_checkin_bed.addItem("Double");
            combo_checkin_bed.addItem("Twin");
        } else if (type.equals("Family")) {
            combo_checkin_bed.addItem("Double");
            combo_checkin_bed.addItem("Mix");
        }
        updateRoomComboBox();
    }
    
    
    // method pengisi field harga
    public void updatePrice() {
        // mengambil data dari combo box tipe kamar dan tipe ranjang
        String tipe = combo_checkin_tipe.getSelectedItem().toString();
        String ranjang = combo_checkin_bed.getSelectedItem().toString();

        // Penghitung jumlah hari
        SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");
        String inputString1 = txt_checkin_date.getText();
        String inputString2 = txt_checkin_date2.getText();

        try {
            // menghubungkan koneksi ke database
            Connection kon = DriverManager.getConnection(database,user,pass);
            // query untuk mengambil data dari setiap combo box
            String SQL = "SELECT harga FROM tabel_kamar WHERE tipe_kamar = ? AND tipe_ranjang = ?";
            PreparedStatement statement = kon.prepareStatement(SQL);
            statement.setString(1, tipe);
            statement.setString(2, ranjang);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Date date1 = dtf.parse(inputString1);
                Date date2 = dtf.parse(inputString2);
                // konversi tanggal untuk dihitung selisihnya
                long timeDiff = Math.abs(date2.getTime()- date1.getTime());
                long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
                int harga = resultSet.getInt("harga");
                double value = harga*daysDiff;
                txt_checkin_temp.setText(String.valueOf(value));
                txt_checkin_harga.setText(String.valueOf(kurs.format(value)));
            }

            resultSet.close();
            statement.close();
            kon.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_checkin_nama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_checkin_telepon = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_checkin_email = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        combo_checkin_jk = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        txt_checkin_kewarganegaraan = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_checkin_date = new javax.swing.JTextField();
        txt_checkin_nik = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_checkin_alamat = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        combo_checkin_bed = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        combo_checkin_tipe = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        combo_checkin_nomor = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        btn_simpan = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        txt_checkin_date2 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txt_checkin_harga = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txt_checkin_temp = new javax.swing.JTextField();

        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(18, 25, 44));

        jLabel2.setForeground(new java.awt.Color(242, 242, 255));
        jLabel2.setText("Nama");

        jLabel3.setForeground(new java.awt.Color(242, 242, 255));
        jLabel3.setText("No. Telepon");

        jLabel4.setForeground(new java.awt.Color(242, 242, 255));
        jLabel4.setText("Kewarganegaraan");

        jLabel5.setForeground(new java.awt.Color(242, 242, 255));
        jLabel5.setText("Jenis Kelamin");

        combo_checkin_jk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laki-laki", "Perempuan", " " }));
        combo_checkin_jk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_checkin_jkActionPerformed(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(242, 242, 255));
        jLabel6.setText("E-mail");

        jLabel7.setForeground(new java.awt.Color(242, 242, 255));
        jLabel7.setText("NIK (Nomor Induk Kependudukan)");

        jLabel8.setForeground(new java.awt.Color(242, 242, 255));
        jLabel8.setText("Alamat");

        jLabel9.setForeground(new java.awt.Color(242, 242, 255));
        jLabel9.setText("Tanggal Check In");

        jLabel10.setForeground(new java.awt.Color(242, 242, 255));
        jLabel10.setText("Tipe Kamar");

        combo_checkin_bed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_checkin_bedActionPerformed(evt);
            }
        });

        jLabel11.setForeground(new java.awt.Color(242, 242, 255));
        jLabel11.setText("Tipe Ranjang");

        combo_checkin_tipe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Standard", "Family", "Deluxe" }));
        combo_checkin_tipe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_checkin_tipeActionPerformed(evt);
            }
        });

        jLabel12.setForeground(new java.awt.Color(242, 242, 255));
        jLabel12.setText("Nomor Kamar");

        combo_checkin_nomor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_checkin_nomorActionPerformed(evt);
            }
        });

        jLabel13.setForeground(new java.awt.Color(242, 242, 255));
        jLabel13.setText("Tanggal Check Out (yyyy-mm-dd)");

        btn_simpan.setBackground(new java.awt.Color(249, 56, 33));
        btn_simpan.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_simpan.setForeground(new java.awt.Color(242, 242, 242));
        btn_simpan.setText("SUBMIT");
        btn_simpan.setBorderPainted(false);
        btn_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanActionPerformed(evt);
            }
        });

        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        txt_checkin_date2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_checkin_date2KeyReleased(evt);
            }
        });

        jLabel15.setForeground(new java.awt.Color(242, 242, 255));
        jLabel15.setText("Harga");

        txt_checkin_harga.setEditable(false);
        txt_checkin_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_checkin_hargaActionPerformed(evt);
            }
        });

        jLabel16.setForeground(new java.awt.Color(242, 242, 255));
        jLabel16.setText("Rp.");

        txt_checkin_temp.setEditable(false);
        txt_checkin_temp.setBackground(new java.awt.Color(18, 25, 44));
        txt_checkin_temp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_checkin_tempActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel14))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(txt_checkin_telepon, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(jLabel4)
                                            .addComponent(combo_checkin_jk, 0, 210, Short.MAX_VALUE)
                                            .addComponent(txt_checkin_kewarganegaraan, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(jLabel5)
                                            .addComponent(txt_checkin_nama, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                                        .addGap(25, 25, 25)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel7)
                                            .addComponent(txt_checkin_alamat, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(txt_checkin_date, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(txt_checkin_nik, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(jLabel13)
                                            .addComponent(txt_checkin_date2))
                                        .addGap(31, 31, 31)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(combo_checkin_nomor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel12)
                                                        .addGap(0, 0, Short.MAX_VALUE))))
                                            .addComponent(combo_checkin_tipe, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(combo_checkin_bed, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txt_checkin_email, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel6)
                                                    .addComponent(jLabel10)
                                                    .addComponent(jLabel11))
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addComponent(btn_simpan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)))
                        .addGap(22, 22, 22))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_checkin_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_checkin_temp, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(135, 135, 135))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_checkin_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_checkin_telepon, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_checkin_kewarganegaraan, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_checkin_nik, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txt_checkin_email, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(24, 24, 24)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_checkin_alamat, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(combo_checkin_tipe, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_checkin_date, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(combo_checkin_bed, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(combo_checkin_jk, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel13)))
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_checkin_date2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(combo_checkin_nomor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)))
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_checkin_harga, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(txt_checkin_temp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(btn_simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void combo_checkin_jkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_checkin_jkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo_checkin_jkActionPerformed

    private void combo_checkin_bedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_checkin_bedActionPerformed
        // TODO add your handling code here:
        updateRoomComboBox();
        updatePrice();
    }//GEN-LAST:event_combo_checkin_bedActionPerformed

    private void combo_checkin_tipeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_checkin_tipeActionPerformed
        // TODO add your handling code here:
        updateBedComboBox();
        updateRoomComboBox();
    }//GEN-LAST:event_combo_checkin_tipeActionPerformed

    private void combo_checkin_nomorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_checkin_nomorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo_checkin_nomorActionPerformed

    private void btn_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanActionPerformed
        // TODO add your handling code here:
        // pointer langsung mengarah ke field nama
        txt_checkin_nama.requestFocus();
        
        // jika data tidak diisi, pengisian harus dilengkapi
        if((txt_checkin_nama.getText().isEmpty())||(txt_checkin_nik.getText().isEmpty())
                ||(txt_checkin_email.getText().isEmpty())||(txt_checkin_alamat.getText().isEmpty())){
            JOptionPane.showMessageDialog(null, "Data tidak boleh kosong, silahkan dilengkapi!");
            txt_checkin_nama.requestFocus();
        }
        // jika sudah diisi
        else{
            try{
                // menghubungkan koneksi ke database
                Class.forName(driver);
                Connection kon = DriverManager.getConnection(database,user,pass);
                Statement stt=kon.createStatement();
                // query yang akan digunakan untuk memasukkan data yang telah diisi
                String SQL = "INSERT INTO tabel_checkin(nama,"
                        + "nik,"
                        + "jenis_kelamin,"
                        + "email,"
                        + "nomor_telepon,"
                        + "kewarganegaraan,"
                        + "alamat,"
                        + "nomor_kamar,"
                        + "tipe_kamar,"
                        + "tipe_ranjang,"
                        + "harga,"
                        + "tanggal_checkin,"
                        + "tanggal_checkout) "
                        + "VALUES"
                        // pengambilan data dari setiap field dan combo box
                        + "('"+txt_checkin_nama.getText()+"',"
                        + " '"+txt_checkin_nik.getText()+" ',"
                        + " '"+combo_checkin_jk.getSelectedItem().toString()+" ',"
                        + " '"+txt_checkin_email.getText()+" ',"
                        + " '"+txt_checkin_telepon.getText()+" ',"
                        + " '"+txt_checkin_kewarganegaraan.getText()+" ',"
                        + " '"+txt_checkin_alamat.getText()+" ',"
                        + " '"+combo_checkin_nomor.getSelectedItem().toString()+" ',"
                        + " '"+combo_checkin_tipe.getSelectedItem().toString()+" ',"
                        + " '"+combo_checkin_bed.getSelectedItem().toString()+" ',"
                        + " '"+txt_checkin_temp.getText()+" ',"
                        + " '"+txt_checkin_date.getText()+" ',"
                        + " '"+txt_checkin_date2.getText()+" ');";
                // query yang akan digunakan untuk mengubah status nomor kamar yang akan diisi penginap
                String SQL2 = "UPDATE `tabel_kamar` SET `status` = 'Terisi' WHERE `status` = 'Kosong' AND"
                        + " `nomor_kamar` ="
                        + "'"+combo_checkin_nomor.getSelectedItem().toString()+"' AND"
                        + " `tipe_kamar` ="
                        + "'"+combo_checkin_tipe.getSelectedItem().toString()+"' AND"
                        + " `tipe_ranjang` ="
                        + "'"+combo_checkin_bed.getSelectedItem().toString()+"';";
                // query yang akan digunakan untuk memasukkan data ke daftar pelanggan yang sedang menginap
                String SQL3 = "INSERT INTO tabel_penginap(nama,"
                        + "nomor_kamar,"
                        + "tanggal_checkin) "
                        + "VALUES"
                        + "('"+txt_checkin_nama.getText()+"',"
                        + " '"+combo_checkin_nomor.getSelectedItem().toString()+"',"
                        + " '"+txt_checkin_date.getText()+"');";
                // mengeksekusi setiap query
                stt.executeUpdate(SQL);
                stt.executeUpdate(SQL2);
                stt.executeUpdate(SQL3);
                stt.close();
                kon.close();
                JOptionPane.showMessageDialog(null, "Data telah tersimpan!");

            }
            catch(Exception ex){
                JOptionPane.showMessageDialog(null, "Kamar yang dipilih telah terisi","Error",JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_simpanActionPerformed

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel14MouseClicked

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        // TODO add your handling code here:
        try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Medium.ttf"));
            fn = fn.deriveFont(Font.PLAIN,12);
            jLabel2.setFont(fn);
            jLabel3.setFont(fn);
            jLabel4.setFont(fn);
            jLabel5.setFont(fn);
            jLabel6.setFont(fn);
            jLabel7.setFont(fn);
            jLabel8.setFont(fn);
            jLabel9.setFont(fn);
            jLabel10.setFont(fn);
            jLabel11.setFont(fn);
            jLabel12.setFont(fn);
            jLabel13.setFont(fn);
            txt_checkin_nama.setFont(fn);
            txt_checkin_telepon.setFont(fn);
            txt_checkin_email.setFont(fn);
            txt_checkin_kewarganegaraan.setFont(fn);
            txt_checkin_date.setFont(fn);
            txt_checkin_nik.setFont(fn);
            txt_checkin_alamat.setFont(fn);
            txt_checkin_date2.setFont(fn);
            combo_checkin_jk.setFont(fn);
            combo_checkin_bed.setFont(fn);
            combo_checkin_tipe.setFont(fn);
            combo_checkin_nomor.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Bold.ttf"));
            fn = fn.deriveFont(Font.PLAIN,14);
            btn_simpan.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formInternalFrameOpened

    private void txt_checkin_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_checkin_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_checkin_hargaActionPerformed

    private void txt_checkin_tempActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_checkin_tempActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_checkin_tempActionPerformed

    private void txt_checkin_date2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_checkin_date2KeyReleased
        // TODO add your handling code here:
        updatePrice();
    }//GEN-LAST:event_txt_checkin_date2KeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_simpan;
    private javax.swing.JComboBox<String> combo_checkin_bed;
    private javax.swing.JComboBox<String> combo_checkin_jk;
    private javax.swing.JComboBox<String> combo_checkin_nomor;
    private javax.swing.JComboBox<String> combo_checkin_tipe;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txt_checkin_alamat;
    private javax.swing.JTextField txt_checkin_date;
    private javax.swing.JTextField txt_checkin_date2;
    private javax.swing.JTextField txt_checkin_email;
    private javax.swing.JTextField txt_checkin_harga;
    private javax.swing.JTextField txt_checkin_kewarganegaraan;
    private javax.swing.JTextField txt_checkin_nama;
    private javax.swing.JTextField txt_checkin_nik;
    private javax.swing.JTextField txt_checkin_telepon;
    private javax.swing.JTextField txt_checkin_temp;
    // End of variables declaration//GEN-END:variables
}
