
import com.mysql.jdbc.PreparedStatement;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */

public class transaksi extends javax.swing.JInternalFrame {
koneksi dbsetting;
String driver,database,user,pass;
DecimalFormat kurs;
DecimalFormatSymbols format;

    /**
     * Creates new form transaksi
     */
    public transaksi() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
        
        // koneksi ke database
        dbsetting = new koneksi();
        driver = dbsetting.SettingPanel("DBDriver");
        database = dbsetting.SettingPanel("DBDatabase");
        user = dbsetting.SettingPanel("DBUsername");
        pass = dbsetting.SettingPanel("DBPassword");
        
        /* format rupiah */
        kurs = (DecimalFormat)DecimalFormat.getInstance();
        format = new DecimalFormatSymbols();
        format.setMonetaryDecimalSeparator(',');
        format.setGroupingSeparator('.');
        kurs.setDecimalFormatSymbols(format);
        
        /* menyembunyikan field */
        jTable1.setModel(tableModel);
        
        settableload();
        
        // menampilkan data dari baris tabel ke text area
        jTable1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent event) {
                // When a row is selected, fetch data and display it in the JTextArea
                if (!event.getValueIsAdjusting()) {
                    int selectedRow = jTable1.getSelectedRow();
                    if (selectedRow >= 0) {
                        displayReceipt(selectedRow);
                    }
                }
            }
        });
    }
    
    // pengatur penampilan tabel data
    private javax.swing.table.DefaultTableModel tableModel = getDefaultTabelModel();
    private javax.swing.table.DefaultTableModel getDefaultTabelModel()
    
            {
    return new javax.swing.table.DefaultTableModel
            (
                new Object[][] {},
                // penamaan untuk setiap kolom/field
                new String [] {"Nama", "Tipe Kamar", "Tipe Ranjang", "Nomor Kamar", "Tanggal Check-In", "Tanggal Check-Out", "Total hari", "Harga", "Pembayaran"}   
            )
            {
                boolean[] canEdit = new boolean[]
                {
                    false,false,false,false,false
                };
                
                public boolean idCellEditable(int rowIndex, int columnIndex)
                {
                    return canEdit[columnIndex];
                }
            };
    }
    
    // deklarasi variabel array untuk setiap kolom/field yang akan dimasukkan data dari database
    String[] data = new String[9];
    
    private void settableload() {
    try {
        Class.forName(driver);
        Connection kon = DriverManager.getConnection(database, user, pass);

        // mengambil data dari setiap kolom/field di tabel transaksi
        Statement stt = kon.createStatement();
        String SQL = "SELECT * FROM tabel_transaksi";
        ResultSet res = stt.executeQuery(SQL);

        // memasukkan data ke setiap kolom/field
        while (res.next()) {
            data[0] = res.getString(1);
            data[1] = res.getString(2);
            data[2] = res.getString(3);
            data[3] = res.getString(4);
            data[4] = res.getString(5);
            data[5] = res.getString(6);
            data[6] = res.getString(7);
            data[7] = res.getString(8);
            data[8] = res.getString(9);
            tableModel.addRow(data);
        }

        res.close();
        stt.close();
        kon.close();
        
    } catch (Exception ex) {
        System.err.println(ex.getMessage());
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
    }
    
    // menampilkan data ke text area ketika memilih baris tabel
    private void displayReceipt(int selectedRow) {
        // Fetch data from the selected row in the JTable
        Object[] rowData = new Object[jTable1.getColumnCount()];
        for (int i = 0; i < jTable1.getColumnCount(); i++) {
            rowData[i] = jTable1.getValueAt(selectedRow, i);
        }
        
        // mengubah tipe data menjadi string dan mengatur format penulisannya
        String value = rowData[7].toString();
        Double value2 = Double.valueOf(value);
        String harga = kurs.format(value2);
        
        // isi text area
        String receipt = "\tRECEIPT \n\n";
        receipt += "Nama\t: " + rowData[0] + "\n";
        receipt += "Tipe Kamar\t: " + rowData[1] + "\n";
        receipt += "Tipe Ranjang\t: " + rowData[2] + "\n";
        receipt += "Nomor Kamar\t: " + rowData[3] + "\n";
        receipt += "Tgl. Check-In\t: " + rowData[4] + "\n";
        receipt += "Tgl. Check-Out\t: " + rowData[5] + "\n";
        receipt += "Total Hari\t: " + rowData[6] + "\n";
        receipt += "Harga\t: Rp. " + harga + "\n";
        receipt += "Pembayaran\t: " + rowData[8] + "\n";
        
        jTextArea1.setText(receipt);
    }
    
    private void transaksiAuto(){
        try{
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = Calendar.getInstance();
            String dateDb = formatter.format(cal.getTime());
            
            Connection kon = DriverManager.getConnection(database,user,pass);
            String query = "SELECT * FROM tabel_checkout WHERE tanggal_checkout = ? ";
            java.sql.PreparedStatement statement = kon.prepareStatement(query);
            statement.setString(1, dateDb);
            ResultSet resultSet = statement.executeQuery();
            
            while(resultSet.next()){
                String namadb = resultSet.getString("nama");
                String outdb = resultSet.getString("tanggal_checkout");
                String indb = resultSet.getString("tanggal_checkin");
                double hargadb = resultSet.getDouble("harga");
                
                insertAuto(kon,namadb,outdb,indb,hargadb);
            }
            
            resultSet.close();
            statement.close();
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
        private static void insertAuto(Connection kon, String namadb, String outdb, String indb, double hargadb)
            throws SQLException{
        String insertquery = "INSERT INTO tabel_transaksi(nama,"
                        + "tanggal_checkout,"
                        + "tanggal_checkin, "
                        + "total_harga)"
                        + "VALUES(?,?,?,?)";
        java.sql.PreparedStatement insert = kon.prepareStatement(insertquery);
        insert.setString(1, namadb);
        insert.setString(2, outdb);
        insert.setString(3, indb);
        insert.setDouble(4, hargadb);
        insert.close();
    }
    
    public void updateDays() {
        // Penghitung jumlah hari
       SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");

    try {
        Connection kon = DriverManager.getConnection(database, user, pass);
        String SQL = "SELECT tanggal_checkin, tanggal_checkout, harga FROM tabel_transaksi";
        java.sql.PreparedStatement statement = kon.prepareStatement(SQL);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            String checkinStr = resultSet.getString("tanggal_checkin");
            String checkoutStr = resultSet.getString("tanggal_checkout");
            Date date1 = dtf.parse(checkinStr);
            Date date2 = dtf.parse(checkoutStr);
            long timeDiff = Math.abs(date2.getTime() - date1.getTime());
            long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
            int harga = resultSet.getInt("harga");
            double value = harga*daysDiff;

            String SQL2 = "UPDATE tabel_transaksi SET total_hari = ? WHERE tanggal_checkin = ? AND tanggal_checkout = ?";
            java.sql.PreparedStatement updateStatement = kon.prepareStatement(SQL2);
            updateStatement.setLong(1, daysDiff);
            updateStatement.setString(2, checkinStr);
            updateStatement.setString(3, checkoutStr);
            updateStatement.executeUpdate();

            updateStatement.close();
        }

            resultSet.close();
            statement.close();
            kon.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(18, 25, 44));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(242, 242, 242));
        jLabel1.setText("Cari berdasarkan tanggal Check-Out ");

        jButton1.setBackground(new java.awt.Color(249, 56, 33));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(242, 242, 242));
        jButton1.setText("CARI");
        jButton1.setBorderPainted(false);
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setMinimumSize(new java.awt.Dimension(13, 25));
        jScrollPane2.setViewportView(jTextArea1);

        jButton3.setBackground(new java.awt.Color(249, 56, 33));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(242, 242, 242));
        jButton3.setText("SEGARKAN");
        jButton3.setBorderPainted(false);
        jButton3.setFocusPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(249, 56, 33));
        jButton4.setForeground(new java.awt.Color(242, 242, 242));
        jButton4.setText("MASUKAN TRANSAKSI BARU");
        jButton4.setBorderPainted(false);
        jButton4.setFocusPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(173, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(6, 6, 6)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(33, 33, 33))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(140, 140, 140)
                        .addComponent(jButton4)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1)
                        .addComponent(jButton3)))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        // TODO add your handling code here:
         try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Medium.ttf"));
            fn = fn.deriveFont(Font.PLAIN,12);
            jLabel1.setFont(fn);
            jTextField1.setFont(fn);
            jTable1.setFont(fn);
            jTextArea1.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
         
         try {
            Font fn = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("font/Poppins-Bold.ttf"));
            fn = fn.deriveFont(Font.PLAIN,12);
            jButton1.setFont(fn);
            jButton3.setFont(fn);
            jButton4.setFont(fn);
        } catch (FontFormatException | IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formInternalFrameOpened

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         tableModel.setRowCount(0);
    try {
        Class.forName(driver);
        Connection kon = DriverManager.getConnection(database, user, pass);

        String SQL = "SELECT * FROM tabel_transaksi WHERE tanggal_checkout LIKE ?";
        java.sql.PreparedStatement preparedStatement = kon.prepareStatement(SQL);
        String keyword = jTextField1.getText();
        preparedStatement.setString(1, "%" + keyword + "%");

        ResultSet res = preparedStatement.executeQuery();
        String data[] = new String[9];
        while (res.next()) {
            data[0] = res.getString(1);
            data[1] = res.getString(2);
            data[2] = res.getString(3);
            data[3] = res.getString(4);
            data[4] = res.getString(5);
            data[5] = res.getString(6);
            data[6] = res.getString(7);
            data[7] = res.getString(8);
            data[8] = res.getString(9);
            tableModel.addRow(data);
        }
        res.close();
        preparedStatement.close();
        kon.close();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
    }
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_formComponentShown

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        tableModel.setRowCount(0);
        settableload();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        setVisible(true);
        new datatransaksi().setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
